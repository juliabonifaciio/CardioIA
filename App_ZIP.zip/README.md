# CardioIA — versão atualizada

Aplicação educacional em React para registro e acompanhamento de aferições de pressão arterial, atualizada conforme a aula de 09/09/2026.

## O que foi implementado

- Estado centralizado no `App.jsx`.
- Quatro telas: Início, Pacientes, Aferições e Perfil.
- Cadastro e seleção de pacientes.
- Cada aferição recebe `pacienteId`, evitando mistura de históricos.
- Persistência em `localStorage` na chave `cardioia-dados-v2`.
- Compatibilidade de migração com a chave antiga `cardioia-afericoes`.
- Contexto da aferição: rotina, dor, repouso ou exercício.
- Filtro das aferições pelo paciente selecionado.
- Classificação educacional da pressão.
- Análise de perfil baseada no histórico.
- Persistência após alterações e sobrevivência dos dados ao F5.
- Navegação por estado, sem React Router, conforme a arquitetura da aula.

## Executar

```bash
npm install
npm run dev
```

Depois, abra a URL indicada pelo Vite, normalmente `http://localhost:5173/`.

> **Aviso:** o projeto é educacional. Os selos e análises não são diagnóstico médico e não substituem avaliação profissional.
