import FormPaciente from '../components/FormPaciente.jsx'
import ListaPacientes from '../components/ListaPacientes.jsx'

export default function Pacientes({ pacientes, pacienteAtualId, afericoes, onSalvar, onSelecionar }) {
  return <section className="painel"><FormPaciente onSalvar={onSalvar} /><h2>Pacientes cadastrados</h2><ListaPacientes pacientes={pacientes} pacienteAtualId={pacienteAtualId} afericoes={afericoes} onSelecionar={onSelecionar} /></section>
}
