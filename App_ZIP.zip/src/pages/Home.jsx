export default function Home({ totalPacientes, totalAfericoes, pacienteAtual, onIrPacientes, onIrAfericoes }) {
  return (
    <section className="painel">
      <h2>Olá. Vamos acompanhar a pressão.</h2>
      <p>Agora o CardioIA separa as aferições por paciente. O perfil selecionado é usado para registrar e consultar apenas as medições daquele paciente.</p>
      <div className="resumo-grid"><div><strong>{totalPacientes}</strong><span>paciente(s)</span></div><div><strong>{totalAfericoes}</strong><span>aferição(ões)</span></div><div><strong>{pacienteAtual?.nome ?? 'Nenhum'}</strong><span>paciente atual</span></div></div>
      <div className="acoes-home"><button type="button" className="botao-principal" onClick={onIrPacientes}>Cadastrar ou escolher paciente</button><button type="button" className="botao-secundario" onClick={onIrAfericoes}>Ir para aferições</button></div>
    </section>
  )
}
