import PerfilPaciente from '../components/PerfilPaciente.jsx'

export default function Perfil({ paciente, afericoes, onIrPacientes }) {
  if (!paciente) return <section className="painel"><h2>Nenhum paciente selecionado</h2><p>Selecione um paciente para visualizar o perfil.</p><button type="button" className="botao-principal" onClick={onIrPacientes}>Ir para pacientes</button></section>
  return <section className="painel"><PerfilPaciente paciente={paciente} afericoes={afericoes} /></section>
}
