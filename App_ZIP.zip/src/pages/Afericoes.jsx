import FormAfericao from '../components/FormAfericao.jsx'
import ListaAfericoes from '../components/ListaAfericoes.jsx'

export default function Afericoes({ paciente, afericoes, onSalvar, onRemover, onIrPacientes }) {
  if (!paciente) return <section className="painel"><h2>Selecione um paciente</h2><p>Para evitar misturar medições, primeiro escolha ou cadastre um paciente.</p><button type="button" className="botao-principal" onClick={onIrPacientes}>Ir para pacientes</button></section>
  return <section className="painel"><p className="hint">Gravando em <strong>{paciente.nome}</strong></p><FormAfericao onSalvar={onSalvar} /><h2>Histórico de {paciente.nome}</h2><ListaAfericoes afericoes={afericoes} onRemover={onRemover} /></section>
}
