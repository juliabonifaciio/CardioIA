const STORAGE_KEY = 'cardioia-dados-v2'
const LEGACY_KEY = 'cardioia-afericoes'

export function estadoVazio() {
  return { pacientes: [], pacienteAtualId: null, afericoes: [] }
}

export function lerEstado() {
  try {
    const salvo = localStorage.getItem(STORAGE_KEY)
    if (salvo) {
      const dados = JSON.parse(salvo)
      return {
        pacientes: Array.isArray(dados.pacientes) ? dados.pacientes : [],
        pacienteAtualId: dados.pacienteAtualId ?? null,
        afericoes: Array.isArray(dados.afericoes) ? dados.afericoes : [],
      }
    }

    const legado = localStorage.getItem(LEGACY_KEY)
    if (legado) {
      const antigas = JSON.parse(legado)
      const pacienteId = crypto.randomUUID()
      return {
        pacientes: [{ id: pacienteId, nome: 'Paciente importado', idade: null, criadoEm: new Date().toISOString() }],
        pacienteAtualId: pacienteId,
        afericoes: Array.isArray(antigas)
          ? antigas.map((item) => ({ ...item, pacienteId: item.pacienteId ?? pacienteId }))
          : [],
      }
    }
  } catch {
    return estadoVazio()
  }

  return estadoVazio()
}

export function salvarEstado(dados) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(dados))
}
