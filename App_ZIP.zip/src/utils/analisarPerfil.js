import { classificarPressao } from './classificarPressao.js'

export function analisarPerfil(afericoes) {
  if (!afericoes.length) {
    return { rotulo: 'Sem histórico', nivel: 'normal', texto: 'Ainda não há aferições para analisar.' }
  }

  const ordenadas = [...afericoes].sort(
    (a, b) => new Date(a.registradoEm).getTime() - new Date(b.registradoEm).getTime(),
  )
  const ultima = ordenadas.at(-1)
  const classeUltima = classificarPressao(ultima.sistolica, ultima.diastolica)

  if (classeUltima.nivel === 'crise') {
    return { rotulo: 'Cuidados médicos', nivel: 'crise', texto: 'A última medição está na faixa de crise. Este selo é educacional e não substitui avaliação profissional.' }
  }

  const anteriores = ordenadas.slice(0, -1)
  const referencia = anteriores.at(-1)
  const deltaS = referencia ? Number(ultima.sistolica) - Number(referencia.sistolica) : 0

  if (referencia && deltaS >= 15 && ultima.contexto === 'dor') {
    return { rotulo: 'Elevação com dor', nivel: 'atencao', texto: `A sistólica subiu ${deltaS} mmHg em relação à medição anterior, registrada durante dor.` }
  }

  const altas = ordenadas.filter((item) => {
    const nivel = classificarPressao(item.sistolica, item.diastolica).nivel
    return nivel === 'alta' || nivel === 'crise'
  }).length

  if (altas >= 2 || altas / ordenadas.length >= 0.5) {
    return { rotulo: 'Perfil hipertensivo', nivel: 'alta', texto: 'Há várias medições classificadas como altas neste recorte educacional.' }
  }

  if (classeUltima.nivel === 'alta' || classeUltima.nivel === 'limite' || classeUltima.nivel === 'atencao') {
    return { rotulo: 'Atenção na última medição', nivel: 'atencao', texto: `A última medição foi classificada como ${classeUltima.rotulo.toLowerCase()}.` }
  }

  return { rotulo: 'Estável neste recorte', nivel: 'normal', texto: 'As medições disponíveis não acionaram nenhuma das regras de atenção.' }
}
