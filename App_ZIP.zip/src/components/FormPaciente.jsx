import { useState } from 'react'

const formInicial = { nome: '', idade: '' }

export default function FormPaciente({ onSalvar }) {
  const [form, setForm] = useState(formInicial)
  const [erro, setErro] = useState('')

  function atualizarCampo(evento) {
    const { name, value } = evento.target
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  function handleSubmit(evento) {
    evento.preventDefault()
    const nome = form.nome.trim()
    const idade = form.idade === '' ? null : Number(form.idade)
    if (!nome) { setErro('Informe o nome do paciente.'); return }
    if (idade !== null && (!Number.isInteger(idade) || idade < 0 || idade > 120)) { setErro('Informe uma idade válida.'); return }
    onSalvar({ nome, idade })
    setForm(formInicial)
    setErro('')
  }

  return (
    <form className="formulario" onSubmit={handleSubmit}>
      <h2>Novo paciente</h2>
      <div className="grade-campos">
        <label>Nome<input name="nome" value={form.nome} onChange={atualizarCampo} placeholder="Maria Silva" /></label>
        <label>Idade (opcional)<input name="idade" type="number" min="0" max="120" value={form.idade} onChange={atualizarCampo} placeholder="58" /></label>
      </div>
      {erro && <p className="erro">{erro}</p>}
      <button type="submit" className="botao-principal">Salvar paciente</button>
    </form>
  )
}
