export default function ListaPacientes({ pacientes, pacienteAtualId, afericoes, onSelecionar }) {
  if (!pacientes.length) return <p className="vazio">Nenhum paciente cadastrado. Crie o primeiro perfil acima.</p>
  return (
    <div className="lista-pacientes">
      {pacientes.map((paciente) => {
        const total = afericoes.filter((item) => item.pacienteId === paciente.id).length
        return (
          <button key={paciente.id} type="button" className={`card-paciente ${paciente.id === pacienteAtualId ? 'selecionado' : ''}`} onClick={() => onSelecionar(paciente.id)}>
            <span><strong>{paciente.nome}</strong>{paciente.idade !== null && paciente.idade !== undefined ? ` · ${paciente.idade} anos` : ''}</span>
            <small>{total} aferição(ões)</small>
          </button>
        )
      })}
    </div>
  )
}
