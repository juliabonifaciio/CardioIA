export default function Header({ titulo, subtitulo, pacienteAtual }) {
  return (
    <header className="header">
      <p className="eyebrow">FIAP · 2TIAPR · 2026</p>
      <h1>{titulo}</h1>
      <p className="lead">{subtitulo}</p>
      {pacienteAtual && <p className="paciente-atual">Paciente em análise: <strong>{pacienteAtual.nome}</strong></p>}
    </header>
  )
}
