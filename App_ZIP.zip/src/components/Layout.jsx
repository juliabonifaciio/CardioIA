import Header from './Header.jsx'
import Nav from './Nav.jsx'

export default function Layout({ children, paginaAtual, onNavegar, pacienteAtual }) {
  return (
    <div className="layout">
      <Header titulo="CardioIA" subtitulo="Registro e acompanhamento das suas aferições de pressão arterial." pacienteAtual={pacienteAtual} />
      <Nav paginaAtual={paginaAtual} onNavegar={onNavegar} />
      <main className="conteudo">{children}</main>
      <footer className="rodape">Material educacional. Os selos são regras de demonstração e não representam diagnóstico médico.</footer>
    </div>
  )
}
