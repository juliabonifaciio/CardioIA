import { analisarPerfil } from '../utils/analisarPerfil.js'
import { classificarPressao } from '../utils/classificarPressao.js'

function formatarData(iso) { return new Date(iso).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) }

export default function PerfilPaciente({ paciente, afericoes }) {
  const analise = analisarPerfil(afericoes)
  const ordenadas = [...afericoes].sort((a, b) => new Date(a.registradoEm) - new Date(b.registradoEm))
  return (
    <div className="perfil">
      <div className="resumo-perfil">
        <div><p className="eyebrow">Perfil educacional</p><h2>{paciente.nome}</h2><p className="hint">{paciente.idade != null ? `${paciente.idade} anos` : 'Idade não informada'} · {afericoes.length} aferição(ões)</p></div>
        <span className={`selo selo-${analise.nivel}`}>{analise.rotulo}</span>
      </div>
      <p className="texto-analise">{analise.texto}</p>
      <h3>Linha do tempo</h3>
      {!ordenadas.length ? <p className="vazio">Sem histórico para este paciente.</p> : <ol className="linha-tempo">{ordenadas.map((item) => { const classe = classificarPressao(item.sistolica, item.diastolica); return <li key={item.id}><strong>{item.sistolica}/{item.diastolica} mmHg</strong><span>{formatarData(item.registradoEm)} · {item.contexto}</span><span className={`selo selo-${classe.nivel}`}>{classe.rotulo}</span></li> })}</ol>}
    </div>
  )
}
